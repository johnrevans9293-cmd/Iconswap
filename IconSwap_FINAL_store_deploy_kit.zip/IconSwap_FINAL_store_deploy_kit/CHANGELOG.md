## 1.0.4 — Final Store Deploy Kit
- Added Codemagic Android/iOS release workflows.
- Added final deployment guide.
- Added store preflight validation.
- Version bumped to 1.0.4+4.

# IconSwap Changelog

## 0.6.0
- Added interactive crop and position editor.
- Added Create Icon end-to-end UI flow.
- Added target/shortcut picker screen.
- Added Home Screen setup handoff.
- Preserved platform-safe behavior and limitations.

## 0.5.0
- Added icon styling service.
- Added border, shadow, rounded and circular style controls.
- Added platform guidance screen.
- Added collections foundation.
- Added target shortcut abstraction.


## 0.8.0
- Added persistent My Icons library.
- Added search and collection filters.
- Added rename, move, and delete actions.
- Connected Create Icon saving to local library storage.
