# Store screenshot plan

Capture screenshots from the **final signed release build**, not mockups.

## Android
1. Home dashboard
2. Create Icon editor
3. Crop/style editor
4. My Icons library
5. Icon Packs
6. Collections
7. Android shortcut setup/instructions
8. Settings/platform limitations

## iPhone
1. Home dashboard
2. Create Icon editor
3. Style controls
4. My Icons library
5. Icon Packs
6. Collections
7. iOS Home Screen/Shortcuts guidance
8. Settings/platform limitations

## Rules
- Use only screenshots of the actual app.
- Do not show unsupported claims such as arbitrary app-icon replacement.
- Do not use third-party trademarks as if they are owned by IconSwap.
- Capture both light and dark UI if useful.
