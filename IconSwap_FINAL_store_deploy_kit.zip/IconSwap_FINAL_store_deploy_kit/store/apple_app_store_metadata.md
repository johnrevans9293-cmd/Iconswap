# Apple App Store metadata — IconSwap

**App name:** IconSwap  
**Subtitle:** Create your custom Home Screen style  
**Category:** Graphics & Design

## Promotional text
Design custom icons, organize your collection, and follow supported Home Screen setup steps.

## Description
IconSwap helps you create a personalized Home Screen look.

Import an image, crop and adjust it, apply shapes and styling, preview your design, and save it to your local icon library. Organize your designs with collections and quickly find recently created icons.

### Features
• Image import and editing  
• Crop, zoom and rotation  
• Brightness and contrast controls  
• Rounded and circular styling  
• Borders and shadows  
• Local icon library  
• Search and collections  
• Built-in visual style packs  
• Home Screen setup guidance

### iOS note
Apple does not provide a public API that allows a third-party app to arbitrarily replace the icons of other installed apps. IconSwap therefore provides supported Shortcuts/Home Screen guidance rather than modifying other apps.

**Support URL:** [PUBLISHER_SUPPORT_URL]  
**Privacy policy URL:** [PUBLISHER_PRIVACY_URL]
