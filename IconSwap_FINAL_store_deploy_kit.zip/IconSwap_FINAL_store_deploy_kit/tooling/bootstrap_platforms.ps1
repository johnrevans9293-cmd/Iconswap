
$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path)
Set-Location $Root

if (-not (Get-Command flutter -ErrorAction SilentlyContinue)) {
  throw "Flutter SDK not found. Install Flutter and run: flutter doctor"
}

$Temp = Join-Path $env:TEMP ("iconswap-" + [guid]::NewGuid())
New-Item -ItemType Directory -Path $Temp | Out-Null

Copy-Item lib "$Temp/lib" -Recurse
Copy-Item test "$Temp/test" -Recurse
Copy-Item docs "$Temp/docs" -Recurse
Copy-Item tooling "$Temp/tooling" -Recurse

flutter create --platforms=android,ios --org com.iconswap --project-name iconswap .

Remove-Item lib,test,docs -Recurse -Force
Copy-Item "$Temp/lib" lib -Recurse
Copy-Item "$Temp/test" test -Recurse
Copy-Item "$Temp/docs" docs -Recurse
Copy-Item "$Temp/tooling/*" tooling -Recurse -Force -ErrorAction SilentlyContinue

Remove-Item $Temp -Recurse -Force

Write-Host "Platform scaffolding created."
Write-Host "Run: flutter pub get; flutter analyze; flutter test"
Write-Host "Android: flutter build appbundle --release"
Write-Host "iOS: open ios/Runner.xcworkspace in Xcode and Archive."
