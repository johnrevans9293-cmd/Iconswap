#!/usr/bin/env python3
from pathlib import Path
import re, sys

root = Path(__file__).resolve().parents[1]
errors = []
checks = [
    "pubspec.yaml",
    "lib/main.dart",
    "lib/app.dart",
    "android",
    "store/google_play_metadata.md",
    "store/apple_app_store_metadata.md",
    "store/SCREENSHOT_PLAN.md",
    "docs/PRIVACY_POLICY_DRAFT.md",
    "codemagic.yaml",
    "FINAL_DEPLOYMENT.md",
]
for item in checks:
    if not (root/item).exists():
        errors.append("Missing: " + item)

m = re.search(r"(?m)^version:\s*(.+)$", (root/"pubspec.yaml").read_text())
if not m:
    errors.append("Missing version")
else:
    print("Version:", m.group(1).strip())

if errors:
    print("STORE PREFLIGHT: FAIL")
    for e in errors: print(" -", e)
    sys.exit(1)

print("STORE PREFLIGHT: PASS")
print("Signing credentials and store-account configuration are intentionally external.")
