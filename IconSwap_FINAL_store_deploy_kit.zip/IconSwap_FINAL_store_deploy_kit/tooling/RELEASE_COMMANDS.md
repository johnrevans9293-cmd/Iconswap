# Release commands

From the project root:

```bash
flutter doctor
flutter pub get
flutter analyze
flutter test
python tooling/check_release_readiness.py
```

Android:

```bash
flutter build appbundle --release
```

The signed AAB should be produced under the Flutter build output after release signing is configured.

iOS (macOS + Xcode required):

```bash
flutter build ios --release
```

Then open the generated iOS workspace/project in Xcode, configure the publisher Team/signing, Archive, validate, and upload to App Store Connect.

Do not commit signing files or credentials.
