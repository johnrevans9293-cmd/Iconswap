# Building IconSwap for release

## Prerequisites
Install Flutter and verify:
`flutter doctor`

## Android
1. Configure a release signing key in your local Android project.
2. Keep `key.properties` and keystore files out of source control.
3. Verify the application ID.
4. Run:
`flutter clean`
`flutter pub get`
`flutter analyze`
`flutter test`
`flutter build appbundle --release`

The resulting Android App Bundle is normally under:
`build/app/outputs/bundle/release/`

## iOS
iOS release builds require macOS and Xcode.
1. Open the `ios/Runner.xcworkspace` in Xcode.
2. Select your Apple Developer Team.
3. Set the Bundle Identifier.
4. Configure signing.
5. Run tests on a physical device.
6. Archive a Release build.
7. Upload the archive through Xcode Organizer/App Store Connect.

Never place Apple certificates, provisioning profiles, App Store Connect API keys, or signing passwords in this repository.
