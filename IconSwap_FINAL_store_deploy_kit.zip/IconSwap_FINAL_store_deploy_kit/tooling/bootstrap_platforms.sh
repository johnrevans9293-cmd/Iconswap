#!/usr/bin/env bash
set -euo pipefail

# Run this script from the IconSwap project root on a machine with Flutter installed.
# It creates complete Android/iOS platform folders from the installed Flutter SDK,
# while preserving IconSwap's Dart source, tests, docs and Android shortcut bridge.

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"

command -v flutter >/dev/null 2>&1 || {
  echo "Flutter SDK not found. Install Flutter and run: flutter doctor"
  exit 1
}

TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT

cp -R lib "$TMP/lib"
cp -R test "$TMP/test"
cp -R docs "$TMP/docs"
cp -R tooling "$TMP/tooling"

# Generate official Flutter platform scaffolding.
flutter create --platforms=android,ios --org com.iconswap --project-name iconswap .

# Restore the application source and project documentation.
rm -rf lib test docs
cp -R "$TMP/lib" lib
cp -R "$TMP/test" test
cp -R "$TMP/docs" docs

# Keep the release tooling that was just added.
cp -R "$TMP/tooling"/* tooling/ 2>/dev/null || true

echo "Platform scaffolding created."
echo "Next:"
echo "  flutter pub get"
echo "  flutter analyze"
echo "  flutter test"
echo "  flutter build appbundle --release"
echo "Then configure signing in Android Studio/Gradle and Apple signing in Xcode."
