from pathlib import Path
import re, sys
root = Path(__file__).resolve().parents[1]
problems = []
pub = root / "pubspec.yaml"
if not pub.exists():
    problems.append("pubspec.yaml is missing")
else:
    text = pub.read_text(encoding="utf-8")
    if not re.search(r"^version:\s*1\.0\.0\+\d+\s*$", text, re.M):
        problems.append("pubspec version is not a 1.0.0 release version")
for rel in ["docs/PRIVACY_POLICY_DRAFT.md","docs/GOOGLE_PLAY_LISTING.md","docs/APPLE_APP_STORE_LISTING.md"]:
    p = root / rel
    if p.exists() and "[INSERT" in p.read_text(encoding="utf-8"):
        problems.append(f"Publisher placeholders remain in {rel}")
for name in ["key.properties","release-key.jks","upload-keystore.jks"]:
    if (root/"android"/name).exists():
        problems.append(f"Signing secret appears inside source tree: {name}")
if problems:
    print("RELEASE READINESS: NOT READY")
    for x in problems: print("- "+x)
    sys.exit(1)
print("RELEASE READINESS: SOURCE CHECK PASSED")
print("Store accounts, signing, screenshots and final device QA still require publisher action.")
