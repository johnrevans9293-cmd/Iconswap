
import 'package:flutter_test/flutter_test.dart';
import 'package:iconswap/services/release_info_service.dart';

void main() {
  test('release metadata is defined', () {
    expect(ReleaseInfoService.appName, 'IconSwap');
    expect(ReleaseInfoService.version, isNotEmpty);
    expect(ReleaseInfoService.build, isNotEmpty);
  });
}
