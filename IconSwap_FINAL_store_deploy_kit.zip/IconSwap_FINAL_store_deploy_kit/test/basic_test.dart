
import 'package:flutter_test/flutter_test.dart';
import 'package:iconswap/app.dart';

void main() {
  testWidgets('IconSwap launches', (tester) async {
    await tester.pumpWidget(const IconSwapApp());
    expect(find.text('IconSwap'), findsOneWidget);
    expect(find.text('Create a new icon'), findsOneWidget);
  });
}
