
import 'package:flutter_test/flutter_test.dart';
import 'package:iconswap/main.dart';

void main() {
  testWidgets('IconSwap shell shows primary navigation', (tester) async {
    await tester.pumpWidget(const IconSwapApp(appearance: 'light'));
    expect(find.text('IconSwap'), findsOneWidget);
    expect(find.text('Home'), findsOneWidget);
    expect(find.text('Create'), findsOneWidget);
    expect(find.text('My Icons'), findsOneWidget);
    expect(find.text('Packs'), findsOneWidget);
  });
}
