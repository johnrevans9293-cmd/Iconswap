
import 'package:flutter/material.dart';

import 'app.dart';
import 'services/app_settings_service.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  final appearance = await AppSettingsService().getAppearance();
  runApp(IconSwapApp(appearance: appearance));
}
