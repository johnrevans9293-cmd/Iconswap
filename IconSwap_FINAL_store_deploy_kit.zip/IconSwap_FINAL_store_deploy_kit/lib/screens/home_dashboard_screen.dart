
import 'package:flutter/material.dart';
import '../services/icon_library_service.dart';

class HomeDashboardScreen extends StatefulWidget {
  final ValueChanged<int> onNavigate;
  const HomeDashboardScreen({super.key, required this.onNavigate});

  @override
  State<HomeDashboardScreen> createState() => _HomeDashboardScreenState();
}

class _HomeDashboardScreenState extends State<HomeDashboardScreen> {
  final _library = IconLibraryService();
  List<SavedIcon> _icons = [];
  bool _loading = true;
  String _query = '';

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final items = await _library.load();
    if (!mounted) return;
    setState(() {
      _icons = items;
      _loading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    final recent = [..._icons]..sort((a, b) => b.createdAt.compareTo(a.createdAt));
    final filtered = recent.where((i) => i.name.toLowerCase().contains(_query.toLowerCase())).take(6).toList();

    return SafeArea(
      child: RefreshIndicator(
        onRefresh: _load,
        child: ListView(
          padding: const EdgeInsets.fromLTRB(20, 20, 20, 32),
          children: [
            Row(
              children: [
                Expanded(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text('IconSwap', style: Theme.of(context).textTheme.headlineMedium?.copyWith(fontWeight: FontWeight.w800)),
                    const SizedBox(height: 4),
                    Text('Make your Home Screen feel like yours.', style: Theme.of(context).textTheme.bodyMedium),
                  ]),
                ),
                IconButton(
                  onPressed: () => widget.onNavigate(5),
                  icon: const Icon(Icons.settings_outlined),
                  tooltip: 'Settings',
                ),
              ],
            ),
            const SizedBox(height: 18),
            TextField(
              onChanged: (v) => setState(() => _query = v),
              decoration: InputDecoration(
                hintText: 'Search your icons',
                prefixIcon: const Icon(Icons.search),
                filled: true,
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(18), borderSide: BorderSide.none),
              ),
            ),
            const SizedBox(height: 20),
            Card(
              child: InkWell(
                borderRadius: BorderRadius.circular(20),
                onTap: () => widget.onNavigate(1),
                child: Padding(
                  padding: const EdgeInsets.all(20),
                  child: Row(
                    children: [
                      Container(
                        width: 56, height: 56,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(18),
                          color: Theme.of(context).colorScheme.primaryContainer,
                        ),
                        child: Icon(Icons.add_photo_alternate_outlined, color: Theme.of(context).colorScheme.onPrimaryContainer),
                      ),
                      const SizedBox(width: 16),
                      const Expanded(child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text('Create a new icon', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w700)),
                          SizedBox(height: 4),
                          Text('Import, edit, style, and save a custom icon.'),
                        ],
                      )),
                      const Icon(Icons.chevron_right),
                    ],
                  ),
                ),
              ),
            ),
            const SizedBox(height: 24),
            _sectionHeader(context, 'Recently Created', () => widget.onNavigate(2)),
            const SizedBox(height: 10),
            if (_loading)
              const Center(child: Padding(padding: EdgeInsets.all(24), child: CircularProgressIndicator()))
            else if (filtered.isEmpty)
              _emptyState(context)
            else
              GridView.builder(
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                itemCount: filtered.length,
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 3, crossAxisSpacing: 12, mainAxisSpacing: 12,
                ),
                itemBuilder: (_, i) {
                  final item = filtered[i];
                  return ClipRRect(
                    borderRadius: BorderRadius.circular(18),
                    child: Container(
                      color: Theme.of(context).colorScheme.surfaceContainerHighest,
                      padding: const EdgeInsets.all(8),
                      child: Image.file(item.imageFile, fit: BoxFit.cover, errorBuilder: (_, __, ___) => const Icon(Icons.image_not_supported_outlined)),
                    ),
                  );
                },
              ),
            const SizedBox(height: 24),
            Row(
              children: [
                Expanded(child: _quickCard(context, 'Icon Packs', Icons.auto_awesome, () => widget.onNavigate(3))),
                const SizedBox(width: 12),
                Expanded(child: _quickCard(context, 'Collections', Icons.folder, () => widget.onNavigate(4))),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _sectionHeader(BuildContext context, String title, VoidCallback onTap) {
    return Row(
      children: [
        Expanded(child: Text(title, style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w800))),
        TextButton(onPressed: onTap, child: const Text('See all')),
      ],
    );
  }

  Widget _emptyState(BuildContext context) => Card(
    child: Padding(
      padding: const EdgeInsets.all(24),
      child: Column(children: [
        const Icon(Icons.palette_outlined, size: 42),
        const SizedBox(height: 10),
        const Text('No icons yet', style: TextStyle(fontWeight: FontWeight.w700)),
        const SizedBox(height: 4),
        const Text('Create your first custom icon to see it here.', textAlign: TextAlign.center),
        const SizedBox(height: 12),
        FilledButton.icon(onPressed: () => widget.onNavigate(1), icon: const Icon(Icons.add), label: const Text('Create icon')),
      ]),
    ),
  );

  Widget _quickCard(BuildContext context, String title, IconData icon, VoidCallback onTap) => Card(
    child: InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(18),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Icon(icon),
          const SizedBox(height: 12),
          Text(title, style: const TextStyle(fontWeight: FontWeight.w700)),
        ]),
      ),
    ),
  );
}
