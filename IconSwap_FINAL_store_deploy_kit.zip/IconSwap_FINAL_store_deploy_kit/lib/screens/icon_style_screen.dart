import 'package:flutter/material.dart';
import '../services/icon_style_service.dart';

class IconStyleScreen extends StatefulWidget {
  final Widget preview;
  const IconStyleScreen({super.key, required this.preview});

  @override
  State<IconStyleScreen> createState() => _IconStyleScreenState();
}

class _IconStyleScreenState extends State<IconStyleScreen> {
  IconStyle style = const IconStyle();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Style icon')),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          Center(
            child: Container(
              width: 190, height: 190,
              decoration: BoxDecoration(
                color: Theme.of(context).colorScheme.surfaceContainerHighest,
                borderRadius: BorderRadius.circular(28),
              ),
              padding: const EdgeInsets.all(22),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(
                  style.circularMask ? 100 : 28,
                ),
                child: Stack(
                  fit: StackFit.expand,
                  children: [
                    widget.preview,
                    CustomPaint(painter: IconStylePainter(style)),
                  ],
                ),
              ),
            ),
          ),
          const SizedBox(height: 28),
          Text('Shape', style: Theme.of(context).textTheme.titleMedium),
          const SizedBox(height: 8),
          Wrap(
            spacing: 8,
            children: [
              ChoiceChip(
                label: const Text('Rounded'),
                selected: !style.circularMask,
                onSelected: (_) => setState(() => style = style.copyWith(circularMask: false)),
              ),
              ChoiceChip(
                label: const Text('Circle'),
                selected: style.circularMask,
                onSelected: (_) => setState(() => style = style.copyWith(circularMask: true)),
              ),
            ],
          ),
          const SizedBox(height: 20),
          _slider('Corner radius', style.cornerRadius, 0, .5,
              (v) => setState(() => style = style.copyWith(cornerRadius: v))),
          _slider('Border', style.borderWidth, 0, 12,
              (v) => setState(() => style = style.copyWith(borderWidth: v))),
          _slider('Shadow blur', style.shadowBlur, 0, 30,
              (v) => setState(() => style = style.copyWith(shadowBlur: v))),
          _slider('Shadow opacity', style.shadowOpacity, 0, .8,
              (v) => setState(() => style = style.copyWith(shadowOpacity: v))),
          _slider('Shadow offset', style.shadowOffset, 0, 16,
              (v) => setState(() => style = style.copyWith(shadowOffset: v))),
          const SizedBox(height: 12),
          FilledButton.icon(
            onPressed: () => Navigator.pop(context, style),
            icon: const Icon(Icons.check),
            label: const Text('Apply style'),
          ),
        ],
      ),
    );
  }

  Widget _slider(String label, double value, double min, double max, ValueChanged<double> onChanged) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text('$label  ${value.toStringAsFixed(1)}'),
        Slider(value: value, min: min, max: max, onChanged: onChanged),
      ],
    );
  }
}