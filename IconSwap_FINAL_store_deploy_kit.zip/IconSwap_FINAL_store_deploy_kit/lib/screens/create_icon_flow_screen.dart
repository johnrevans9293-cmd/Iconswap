import 'dart:io';
import 'package:path_provider/path_provider.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'crop_editor_screen.dart';
import 'target_picker_screen.dart';
import 'icon_style_screen.dart';
import 'platform_guide_screen.dart';
import '../services/icon_style_service.dart';
import '../services/icon_library_service.dart';
import '../services/target_service.dart';

class CreateIconFlowScreen extends StatefulWidget {
  const CreateIconFlowScreen({super.key});

  @override
  State<CreateIconFlowScreen> createState() => _CreateIconFlowScreenState();
}

class _CreateIconFlowScreenState extends State<CreateIconFlowScreen> {
  final picker = ImagePicker();
  File? image;
  TargetShortcut? target;
  IconStyle style = const IconStyle();
  String name = 'My Icon';

  Future<void> pickImage() async {
    final picked = await picker.pickImage(source: ImageSource.gallery);
    if (picked == null) return;
    final file = File(picked.path);
    if (!mounted) return;
    setState(() => image = file);
  }

  Future<void> crop() async {
    if (image == null) return;
    await Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => CropEditorScreen(image: image!)),
    );
  }

  Future<void> chooseTarget() async {
    final result = await Navigator.push<TargetShortcut>(
      context,
      MaterialPageRoute(builder: (_) => const TargetPickerScreen()),
    );
    if (result != null) setState(() => target = result);
  }

  Future<void> styleIcon() async {
    if (image == null) return;
    final result = await Navigator.push<IconStyle>(
      context,
      MaterialPageRoute(
        builder: (_) => IconStyleScreen(preview: Image.file(image!, fit: BoxFit.cover)),
      ),
    );
    if (result != null) setState(() => style = result);
  }

  Future<void> save() async {
    if (image == null) return;

    final directory = await getApplicationDocumentsDirectory();
    final iconsDir = Directory('${directory.path}/icons');
    if (!await iconsDir.exists()) await iconsDir.create(recursive: true);

    final id = DateTime.now().millisecondsSinceEpoch.toString();
    final destination = File('${iconsDir.path}/$id.png');
    await destination.writeAsBytes(await image!.readAsBytes());

    await IconLibraryService().save(
      SavedIcon(
        id: id,
        name: name.trim().isEmpty ? 'My Icon' : name.trim(),
        imagePath: destination.path,
        createdAt: DateTime.now().toIso8601String(),
        collection: 'Favorites',
        targetName: target?.name,
      ),
    );

    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Icon saved to My Icons')),
    );

    showModalBottomSheet(
      context: context,
      showDragHandle: true,
      builder: (_) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              const Text('Icon saved',
                  style: TextStyle(fontSize: 22, fontWeight: FontWeight.w700)),
              const SizedBox(height: 8),
              const Text('Your design is now available in My Icons.'),
              const SizedBox(height: 18),
              FilledButton(
                onPressed: () => Navigator.pop(context),
                child: const Text('Done'),
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Create Icon')),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          Container(
            height: 270,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(30),
              color: Theme.of(context).colorScheme.surfaceContainerHighest,
            ),
            clipBehavior: Clip.antiAlias,
            child: image == null
                ? const Center(child: Icon(Icons.image_outlined, size: 70))
                : Image.file(image!, fit: BoxFit.cover),
          ),
          const SizedBox(height: 18),
          FilledButton.icon(
            onPressed: pickImage,
            icon: const Icon(Icons.photo_library_outlined),
            label: Text(image == null ? 'Choose image' : 'Change image'),
          ),
          if (image != null) ...[
            const SizedBox(height: 10),
            OutlinedButton.icon(
              onPressed: crop,
              icon: const Icon(Icons.crop),
              label: const Text('Crop & position'),
            ),
            const SizedBox(height: 10),
            OutlinedButton.icon(
              onPressed: styleIcon,
              icon: const Icon(Icons.auto_awesome),
              label: const Text('Shape, border & shadow'),
            ),
          ],
          const SizedBox(height: 18),
          TextField(
            decoration: const InputDecoration(
              labelText: 'Icon name',
              border: OutlineInputBorder(),
            ),
            controller: TextEditingController(text: name),
            onChanged: (v) => name = v,
          ),
          const SizedBox(height: 14),
          Card(
            child: ListTile(
              leading: const CircleAvatar(child: Icon(Icons.apps)),
              title: Text(target?.name ?? 'Choose an app or shortcut'),
              subtitle: Text(target == null
                  ? 'Optional — depends on platform support'
                  : 'Target selected'),
              trailing: const Icon(Icons.chevron_right),
              onTap: chooseTarget,
            ),
          ),
          const SizedBox(height: 18),
          FilledButton(
            onPressed: image == null ? null : save,
            child: const Text('Save & add to Home Screen'),
          ),
        ],
      ),
    );
  }
}