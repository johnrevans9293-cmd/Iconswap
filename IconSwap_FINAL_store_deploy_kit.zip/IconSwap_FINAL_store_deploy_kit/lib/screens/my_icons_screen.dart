import 'dart:io';
import 'package:flutter/material.dart';
import '../services/icon_library_service.dart';

class MyIconsScreen extends StatefulWidget {
  const MyIconsScreen({super.key});

  @override
  State<MyIconsScreen> createState() => _MyIconsScreenState();
}

class _MyIconsScreenState extends State<MyIconsScreen> {
  final library = IconLibraryService();
  List<SavedIcon> icons = [];
  String query = '';
  String collection = 'All';

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final items = await library.load();
    if (mounted) setState(() => icons = items);
  }

  List<SavedIcon> get filtered => icons.where((icon) {
    final matchesQuery = icon.name.toLowerCase().contains(query.toLowerCase());
    final matchesCollection = collection == 'All' || icon.collection == collection;
    return matchesQuery && matchesCollection;
  }).toList();

  Future<void> _delete(SavedIcon icon) async {
    await library.delete(icon.id);
    await _load();
  }

  Future<void> _rename(SavedIcon icon) async {
    final controller = TextEditingController(text: icon.name);
    final name = await showDialog<String>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Rename icon'),
        content: TextField(controller: controller, autofocus: true),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')),
          FilledButton(onPressed: () => Navigator.pop(context, controller.text.trim()), child: const Text('Save')),
        ],
      ),
    );
    if (name != null && name.isNotEmpty) {
      await library.rename(icon.id, name);
      await _load();
    }
  }

  Future<void> _move(SavedIcon icon) async {
    const options = ['Favorites', 'Work', 'Social', 'Games'];
    final value = await showModalBottomSheet<String>(
      context: context,
      showDragHandle: true,
      builder: (_) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: options.map((x) => ListTile(
            title: Text(x),
            onTap: () => Navigator.pop(context, x),
          )).toList(),
        ),
      ),
    );
    if (value != null) {
      await library.moveToCollection(icon.id, value);
      await _load();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('My Icons')),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 8),
            child: TextField(
              decoration: const InputDecoration(
                prefixIcon: Icon(Icons.search),
                hintText: 'Search your icons',
                border: OutlineInputBorder(),
              ),
              onChanged: (v) => setState(() => query = v),
            ),
          ),
          SizedBox(
            height: 48,
            child: ListView(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 16),
              children: ['All', 'Favorites', 'Work', 'Social', 'Games'].map((x) {
                return Padding(
                  padding: const EdgeInsets.only(right: 8),
                  child: ChoiceChip(
                    label: Text(x),
                    selected: collection == x,
                    onSelected: (_) => setState(() => collection = x),
                  ),
                );
              }).toList(),
            ),
          ),
          Expanded(
            child: filtered.isEmpty
                ? const Center(
                    child: Padding(
                      padding: EdgeInsets.all(32),
                      child: Text(
                        'No saved icons yet.\nCreate an icon and it will appear here.',
                        textAlign: TextAlign.center,
                      ),
                    ),
                  )
                : GridView.builder(
                    padding: const EdgeInsets.all(16),
                    gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: 2,
                      crossAxisSpacing: 14,
                      mainAxisSpacing: 14,
                      childAspectRatio: .86,
                    ),
                    itemCount: filtered.length,
                    itemBuilder: (_, i) {
                      final icon = filtered[i];
                      return Card(
                        clipBehavior: Clip.antiAlias,
                        child: InkWell(
                          onLongPress: () => _rename(icon),
                          child: Column(
                            children: [
                              Expanded(
                                child: Padding(
                                  padding: const EdgeInsets.all(18),
                                  child: File(icon.imagePath).existsSync()
                                      ? ClipRRect(
                                          borderRadius: BorderRadius.circular(22),
                                          child: Image.file(File(icon.imagePath), fit: BoxFit.cover),
                                        )
                                      : const Icon(Icons.broken_image_outlined, size: 48),
                                ),
                              ),
                              Padding(
                                padding: const EdgeInsets.symmetric(horizontal: 12),
                                child: Text(icon.name, maxLines: 1, overflow: TextOverflow.ellipsis),
                              ),
                              Row(
                                mainAxisAlignment: MainAxisAlignment.end,
                                children: [
                                  IconButton(
                                    tooltip: 'Collection',
                                    onPressed: () => _move(icon),
                                    icon: const Icon(Icons.folder_outlined),
                                  ),
                                  IconButton(
                                    tooltip: 'Delete',
                                    onPressed: () => _delete(icon),
                                    icon: const Icon(Icons.delete_outline),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }
}