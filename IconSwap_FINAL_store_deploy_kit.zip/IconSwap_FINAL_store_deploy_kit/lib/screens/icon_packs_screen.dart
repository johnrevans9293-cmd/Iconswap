import 'package:flutter/material.dart';

class IconPacksScreen extends StatelessWidget {
  const IconPacksScreen({super.key});

  static const categories=['Minimal','Glass','Neon','Dark','Pastel','Gradient','Gaming','Productivity','Nature'];

  @override Widget build(BuildContext context)=>Scaffold(
    appBar:AppBar(title:const Text('Icon Packs')),
    body:ListView(
      padding:const EdgeInsets.all(20),
      children:[
        Text('Explore styles',style:Theme.of(context).textTheme.headlineSmall),
        const SizedBox(height:8),
        const Text('Original starter styles are included. More packs can be added later.'),
        const SizedBox(height:20),
        ...categories.map((c)=>Card(
          child:ListTile(
            leading:CircleAvatar(child:Icon(_icon(c))),
            title:Text(c),
            subtitle:const Text('Starter collection'),
            trailing:const Icon(Icons.chevron_right),
            onTap:()=>_showPack(context,c),
          ),
        )),
      ],
    ),
  );

  IconData _icon(String c)=>switch(c){
    'Minimal'=>Icons.crop_square,
    'Glass'=>Icons.blur_on,
    'Neon'=>Icons.flash_on,
    'Dark'=>Icons.dark_mode,
    'Pastel'=>Icons.palette,
    'Gradient'=>Icons.gradient,
    'Gaming'=>Icons.sports_esports,
    'Productivity'=>Icons.task_alt,
    _=>Icons.eco,
  };

  void _showPack(BuildContext context,String name)=>showModalBottomSheet(
    context:context,
    showDragHandle:true,
    builder:(_)=>Padding(
      padding:const EdgeInsets.all(24),
      child:Column(mainAxisSize:MainAxisSize.min,children:[
        Text(name,style:Theme.of(context).textTheme.headlineSmall),
        const SizedBox(height:12),
        const Text('This starter pack is ready for additional original icon assets.'),
        const SizedBox(height:20),
        FilledButton(onPressed:()=>Navigator.pop(context),child:const Text('Done')),
      ]),
    ),
  );
}
