import 'package:flutter/material.dart';

class PlatformGuideScreen extends StatelessWidget {
  const PlatformGuideScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Add to Home Screen')),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          const Icon(Icons.home_work_outlined, size: 56),
          const SizedBox(height: 16),
          Text('IconSwap uses supported platform workflows.',
              style: Theme.of(context).textTheme.headlineSmall),
          const SizedBox(height: 20),
          const _GuideCard(
            icon: Icons.android,
            title: 'Android',
            body: 'On supported launchers, IconSwap can request a pinned shortcut using Android’s supported shortcut APIs. The shortcut is a separate Home Screen shortcut; it does not modify the installed app package or its original icon.',
          ),
          const _GuideCard(
            icon: Icons.apple,
            title: 'iPhone & iPad',
            body: 'iOS does not provide a public API for third-party apps to replace another app’s icon. IconSwap therefore guides you through supported Shortcuts/Home Screen workflows. Alternate icons are only available to apps that declare them for themselves.',
          ),
          const _GuideCard(
            icon: Icons.security_outlined,
            title: 'Privacy',
            body: 'IconSwap does not need root access, private APIs, package modification, or another app’s private data.',
          ),
        ],
      ),
    );
  }
}

class _GuideCard extends StatelessWidget {
  final IconData icon;
  final String title;
  final String body;
  const _GuideCard({required this.icon, required this.title, required this.body});

  @override
  Widget build(BuildContext context) => Card(
    margin: const EdgeInsets.only(bottom: 14),
    child: Padding(
      padding: const EdgeInsets.all(18),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(icon, size: 28),
          const SizedBox(width: 14),
          Expanded(child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(title, style: Theme.of(context).textTheme.titleMedium),
              const SizedBox(height: 6),
              Text(body),
            ],
          )),
        ],
      ),
    ),
  );
}