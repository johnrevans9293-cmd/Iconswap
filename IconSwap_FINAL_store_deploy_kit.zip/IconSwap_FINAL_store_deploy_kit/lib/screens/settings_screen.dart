
import 'package:flutter/material.dart';
import '../services/app_settings_service.dart';
import 'platform_guide_screen.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});
  @override State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  final _settings = AppSettingsService();
  String _appearance = 'system';
  String _quality = 'High';
  String _shape = 'rounded';
  bool _notifications = true;

  @override
  void initState() { super.initState(); _load(); }

  Future<void> _load() async {
    final a = await _settings.getAppearance();
    final q = await _settings.getIconQuality();
    final s = await _settings.getDefaultShape();
    final n = await _settings.getNotifications();
    if (!mounted) return;
    setState(() { _appearance=a; _quality=q; _shape=s; _notifications=n; });
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: ListView(
        padding: const EdgeInsets.fromLTRB(20, 20, 20, 32),
        children: [
          Text('Settings', style: Theme.of(context).textTheme.headlineMedium?.copyWith(fontWeight: FontWeight.w800)),
          const SizedBox(height: 20),
          _group('Appearance', [
            ListTile(
              leading: const Icon(Icons.brightness_6_outlined),
              title: const Text('Theme'),
              subtitle: Text(_appearance[0].toUpperCase() + _appearance.substring(1)),
              trailing: DropdownButton<String>(
                value: _appearance,
                items: const [
                  DropdownMenuItem(value:'system', child: Text('System')),
                  DropdownMenuItem(value:'light', child: Text('Light')),
                  DropdownMenuItem(value:'dark', child: Text('Dark')),
                ],
                onChanged: (v) async { if (v == null) return; await _settings.setAppearance(v); setState(()=>_appearance=v); },
              ),
            ),
          ]),
          _group('Icon Defaults', [
            ListTile(
              leading: const Icon(Icons.high_quality_outlined),
              title: const Text('Icon quality'),
              subtitle: const Text('Controls saved image output quality.'),
              trailing: DropdownButton<String>(
                value: _quality,
                items: const [
                  DropdownMenuItem(value:'Standard', child: Text('Standard')),
                  DropdownMenuItem(value:'High', child: Text('High')),
                  DropdownMenuItem(value:'Maximum', child: Text('Maximum')),
                ],
                onChanged: (v) async { if (v == null) return; await _settings.setIconQuality(v); setState(()=>_quality=v); },
              ),
            ),
            ListTile(
              leading: const Icon(Icons.crop_square_outlined),
              title: const Text('Default shape'),
              subtitle: Text(_shape == 'circle' ? 'Circle' : 'Rounded'),
              trailing: DropdownButton<String>(
                value: _shape,
                items: const [
                  DropdownMenuItem(value:'rounded', child: Text('Rounded')),
                  DropdownMenuItem(value:'circle', child: Text('Circle')),
                ],
                onChanged: (v) async { if (v == null) return; await _settings.setDefaultShape(v); setState(()=>_shape=v); },
              ),
            ),
          ]),
          _group('Preferences', [
            SwitchListTile(
              secondary: const Icon(Icons.notifications_none),
              title: const Text('Notifications'),
              subtitle: const Text('Allow helpful IconSwap reminders.'),
              value: _notifications,
              onChanged: (v) async { await _settings.setNotifications(v); setState(()=>_notifications=v); },
            ),
          ]),
          _group('Help & Privacy', [
            ListTile(
              leading: const Icon(Icons.phone_android_outlined),
              title: const Text('Platform limitations'),
              subtitle: const Text('Learn what Android and iOS allow.'),
              trailing: const Icon(Icons.chevron_right),
              onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const PlatformGuideScreen())),
            ),
            const ListTile(
              leading: Icon(Icons.lock_outline),
              title: Text('Privacy'),
              subtitle: Text('Icons are stored locally unless a future feature says otherwise.'),
            ),
            const ListTile(
              leading: Icon(Icons.info_outline),
              title: Text('About IconSwap'),
              subtitle: Text('Create your Home Screen style without modifying other apps.'),
            ),
          ]),
        ],
      ),
    );
  }

  Widget _group(String title, List<Widget> children) => Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      Padding(padding: const EdgeInsets.fromLTRB(4, 18, 4, 8), child: Text(title, style: const TextStyle(fontWeight: FontWeight.w800))),
      Card(child: Column(children: children)),
    ],
  );
}
