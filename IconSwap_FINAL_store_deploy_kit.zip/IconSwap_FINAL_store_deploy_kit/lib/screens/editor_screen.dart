import 'dart:io';
import 'package:flutter/material.dart';
import '../services/image_service.dart';

class EditorScreen extends StatefulWidget {
  final String sourcePath;
  const EditorScreen({super.key, required this.sourcePath});
  @override State<EditorScreen> createState()=>_EditorScreenState();
}

class _EditorScreenState extends State<EditorScreen> {
  final service=ImageService();
  double brightness=0, contrast=1, rotation=0;
  double scale=1;
  bool circle=false, busy=false;

  Future<void> save() async {
    setState(()=>busy=true);
    try {
      final path=await service.process(
        sourcePath:widget.sourcePath,
        brightness:brightness,
        contrast:contrast,
        rotation:rotation,
      );
      if(mounted) Navigator.pop(context,path);
    } catch(e) {
      if(mounted) ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content:Text('Could not process image: $e')));
    } finally { if(mounted)setState(()=>busy=false); }
  }

  @override Widget build(BuildContext context)=>Scaffold(
    appBar:AppBar(
      title:const Text('Icon Editor'),
      actions:[IconButton(onPressed:busy?null:save,icon:const Icon(Icons.check_rounded))]
    ),
    body:Column(children:[
      Expanded(
        child:Center(
          child: Container(
            width:300,height:300,
            decoration:BoxDecoration(
              borderRadius:BorderRadius.circular(circle?150:36),
              boxShadow:[BoxShadow(blurRadius:30,color:Colors.black.withOpacity(.18))],
            ),
            clipBehavior:Clip.antiAlias,
            child:Transform.scale(scale:scale,
              child:Transform.rotate(angle:rotation*3.1415926535/180,
                child:ColorFiltered(
                  colorFilter:ColorFilter.matrix(<double>[
                    contrast,0,0,0,brightness*255,
                    0,contrast,0,0,brightness*255,
                    0,0,contrast,0,brightness*255,
                    0,0,0,1,0,
                  ]),
                  child:Image.file(File(widget.sourcePath),fit:BoxFit.cover),
                ))),
          ),
        ),
      ),
      if(busy) const LinearProgressIndicator(),
      Wrap(spacing:8,children:[
        ChoiceChip(label:const Text('Square'),selected:!circle,onSelected:(_)=>setState(()=>circle=false)),
        ChoiceChip(label:const Text('Round'),selected:circle,onSelected:(_)=>setState(()=>circle=true)),
      ]),
      _slider('Zoom',scale,.7,1.4,(v)=>setState(()=>scale=v)),
      _slider('Brightness',brightness,-1,1,(v)=>setState(()=>brightness=v)),
      _slider('Contrast',contrast,.5,2,(v)=>setState(()=>contrast=v)),
      _slider('Rotation',rotation,-180,180,(v)=>setState(()=>rotation=v)),
      const SizedBox(height:10),
    ]),
  );

  Widget _slider(String label,double value,double min,double max,ValueChanged<double> f)=>Column(
    children:[
      Padding(padding:const EdgeInsets.symmetric(horizontal:18),child:Row(children:[
        Text(label),const Spacer(),Text(value.toStringAsFixed(1))
      ])),
      Slider(value:value,min:min,max:max,onChanged:f)
    ]);
}
