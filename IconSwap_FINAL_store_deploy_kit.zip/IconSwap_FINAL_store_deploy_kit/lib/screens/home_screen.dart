import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import '../models/user_icon.dart';
import '../services/storage_service.dart';
import '../services/platform_service.dart';
import 'editor_screen.dart';
import 'icon_packs_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override State<HomeScreen> createState()=>_HomeScreenState();
}
class _HomeScreenState extends State<HomeScreen> {
  final picker=ImagePicker(), storage=StorageService();
  List<UserIcon> icons=[];
  int tab=0;
  @override void initState(){super.initState();load();}
  Future<void> load() async { final x=await storage.load(); if(mounted)setState(()=>icons=x); }

  Future<void> create() async {
    final x=await picker.pickImage(source:ImageSource.gallery,requestFullMetadata:false);
    if(x==null)return;
    final edited=await Navigator.push<String>(context,
      MaterialPageRoute(builder:(_)=>EditorScreen(sourcePath:x.path)));
    if(edited==null)return;
    final controller=TextEditingController(text:'My Icon');
    if(!mounted)return;
    final name=await showDialog<String>(context:context,builder:(_)=>AlertDialog(
      title:const Text('Name your icon'),content:TextField(controller:controller,autofocus:true),
      actions:[TextButton(onPressed:()=>Navigator.pop(context),child:const Text('Cancel')),
      FilledButton(onPressed:()=>Navigator.pop(context,controller.text.trim()),child:const Text('Save'))]));
    if(name==null||name.isEmpty)return;
    final item=UserIcon(id:DateTime.now().microsecondsSinceEpoch.toString(),name:name,
      imagePath:edited,createdAt:DateTime.now());
    final next=[item,...icons]; await storage.save(next);
    if(mounted)setState(()=>icons=next);
  }

  Future<void> addShortcut(UserIcon icon) async {
    final ok=await PlatformService.requestHomeScreenShortcut(name:icon.name,imagePath:icon.imagePath);
    if(!mounted)return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(ok
      ?'Follow the system prompt to add the shortcut.':'This launcher does not support this shortcut workflow.')));
  }

  @override Widget build(BuildContext context)=>Scaffold(
    appBar:AppBar(title:const Text('IconSwap'),actions:[
      IconButton(onPressed:()=>showAboutDialog(context:context,applicationName:'IconSwap',
        applicationVersion:'0.2.0',children:[const Text('Create custom icons and supported Home Screen shortcuts.')]),
        icon:const Icon(Icons.info_outline))
    ]),
    body:tab==0?_home():tab==1?_library():_settings(),
    bottomNavigationBar:NavigationBar(selectedIndex:tab,onDestinationSelected:(i)=>setState(()=>tab=i),
      destinations:const[
        NavigationDestination(icon:Icon(Icons.home_outlined),selectedIcon:Icon(Icons.home),label:'Home'),
        NavigationDestination(icon:Icon(Icons.grid_view),label:'My Icons'),
        NavigationDestination(icon:Icon(Icons.settings_outlined),label:'Settings')]),
    floatingActionButton:tab<2?FloatingActionButton.extended(onPressed:create,
      icon:const Icon(Icons.add),label:const Text('Create Icon')):null);
  Widget _home()=>ListView(padding:const EdgeInsets.all(20),children:[
    Text('Make your Home Screen yours.',style:Theme.of(context).textTheme.headlineSmall),
    const SizedBox(height:8),const Text('Create an icon, edit it, then use supported Home Screen shortcut features.'),
    const SizedBox(height:24),
    Card(
      child:ListTile(
        leading:const CircleAvatar(child:Icon(Icons.auto_awesome)),
        title:const Text('Icon Packs'),
        subtitle:const Text('Browse Minimal, Glass, Neon and more'),
        trailing:const Icon(Icons.chevron_right),
        onTap:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>const IconPacksScreen())),
      ),
    ),
    const SizedBox(height:12),
    if(icons.isEmpty)const Card(child:Padding(padding:EdgeInsets.all(24),
      child:Text('No icons yet. Tap Create Icon to get started.'))),
    if(icons.isNotEmpty)Text('Recently Created',style:Theme.of(context).textTheme.titleLarge),
    if(icons.isNotEmpty)const SizedBox(height:12),
    if(icons.isNotEmpty)_grid(),
  ]);
  Widget _library()=>ListView(padding:const EdgeInsets.all(20),children:[
    Text('My Icons',style:Theme.of(context).textTheme.headlineSmall),
    const SizedBox(height:16),if(icons.isEmpty)const Text('Your saved icons will appear here.')
    else _grid()]);
  Widget _grid()=>GridView.builder(shrinkWrap:true,physics:const NeverScrollableScrollPhysics(),
    gridDelegate:const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount:2,
      crossAxisSpacing:12,mainAxisSpacing:12),itemCount:icons.length,itemBuilder:(_,i){
      final icon=icons[i]; return Card(clipBehavior:Clip.antiAlias,child:InkWell(onTap:()=>addShortcut(icon),
        child:Column(children:[Expanded(child:Image.file(File(icon.imagePath),fit:BoxFit.cover,width:double.infinity)),
          Padding(padding:const EdgeInsets.all(10),child:Text(icon.name,maxLines:1,overflow:TextOverflow.ellipsis))])));
    });
  Widget _settings()=>ListView(padding:const EdgeInsets.all(20),children:[
    Text('Settings',style:Theme.of(context).textTheme.headlineSmall),
    const SizedBox(height:12),
    const ListTile(leading:Icon(Icons.dark_mode),title:Text('Appearance'),subtitle:Text('Uses the system theme')),
    const ListTile(leading:Icon(Icons.lock_outline),title:Text('Privacy'),subtitle:Text('Icons are stored locally by default')),
    const ListTile(leading:Icon(Icons.info_outline),title:Text('Platform limitations'),
      subtitle:Text('Android launcher support varies. iOS does not allow third-party apps to replace arbitrary app icons.')),
  ]);
}
