
import 'package:flutter/material.dart';
import '../services/icon_library_service.dart';

class CollectionsScreen extends StatefulWidget {
  const CollectionsScreen({super.key});
  @override State<CollectionsScreen> createState() => _CollectionsScreenState();
}

class _CollectionsScreenState extends State<CollectionsScreen> {
  final _library = IconLibraryService();
  final _collections = const ['Favorites', 'Work', 'Social', 'Games'];
  Map<String, List<SavedIcon>> _groups = {};

  @override
  void initState() { super.initState(); _load(); }

  Future<void> _load() async {
    final all = await _library.load();
    final map = <String, List<SavedIcon>>{};
    for (final c in _collections) {
      map[c] = all.where((x) => x.collection == c).toList();
    }
    if (!mounted) return;
    setState(() => _groups = map);
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: RefreshIndicator(
        onRefresh: _load,
        child: ListView(
          padding: const EdgeInsets.fromLTRB(20, 20, 20, 32),
          children: [
            Text('Collections', style: Theme.of(context).textTheme.headlineMedium?.copyWith(fontWeight: FontWeight.w800)),
            const SizedBox(height: 8),
            const Text('Keep your icons organized by purpose.'),
            const SizedBox(height: 18),
            ..._collections.map((name) {
              final items = _groups[name] ?? const <SavedIcon>[];
              return Card(
                margin: const EdgeInsets.only(bottom: 12),
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Row(children: [
                    Container(
                      width: 52, height: 52,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(16),
                        color: Theme.of(context).colorScheme.secondaryContainer,
                      ),
                      child: items.isEmpty
                          ? const Icon(Icons.folder_outlined)
                          : ClipRRect(
                              borderRadius: BorderRadius.circular(16),
                              child: Image.file(items.first.imageFile, fit: BoxFit.cover, errorBuilder: (_, __, ___) => const Icon(Icons.folder)),
                            ),
                    ),
                    const SizedBox(width: 14),
                    Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text(name, style: const TextStyle(fontWeight: FontWeight.w800)),
                      const SizedBox(height: 4),
                      Text('${items.length} icon${items.length == 1 ? '' : 's'}'),
                    ])),
                    const Icon(Icons.chevron_right),
                  ]),
                ),
              );
            }),
          ],
        ),
      ),
    );
  }
}
