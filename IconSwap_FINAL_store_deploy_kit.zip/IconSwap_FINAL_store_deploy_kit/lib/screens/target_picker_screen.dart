import 'package:flutter/material.dart';
import '../services/target_service.dart';

class TargetPickerScreen extends StatefulWidget {
  const TargetPickerScreen({super.key});

  @override
  State<TargetPickerScreen> createState() => _TargetPickerScreenState();
}

class _TargetPickerScreenState extends State<TargetPickerScreen> {
  final service = TargetService();
  List<TargetShortcut> targets = const [];
  bool loading = true;
  String query = '';

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final result = await service.discoverSupportedTargets();
    if (!mounted) return;
    setState(() {
      targets = result;
      loading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    final filtered = targets.where((t) =>
      t.name.toLowerCase().contains(query.toLowerCase())).toList();

    return Scaffold(
      appBar: AppBar(title: const Text('Choose target')),
      body: loading
          ? const Center(child: CircularProgressIndicator())
          : targets.isEmpty
              ? _empty(context)
              : ListView(
                  padding: const EdgeInsets.all(20),
                  children: [
                    TextField(
                      decoration: const InputDecoration(
                        prefixIcon: Icon(Icons.search),
                        hintText: 'Search apps or shortcuts',
                        border: OutlineInputBorder(),
                      ),
                      onChanged: (v) => setState(() => query = v),
                    ),
                    const SizedBox(height: 18),
                    ...filtered.map((target) => Card(
                      child: ListTile(
                        leading: const CircleAvatar(child: Icon(Icons.apps)),
                        title: Text(target.name),
                        subtitle: Text(target.packageName ?? 'Supported shortcut'),
                        trailing: const Icon(Icons.chevron_right),
                        onTap: () => Navigator.pop(context, target),
                      ),
                    )),
                  ],
                ),
    );
  }

  Widget _empty(BuildContext context) => Center(
    child: Padding(
      padding: const EdgeInsets.all(32),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const Icon(Icons.touch_app_outlined, size: 64),
          const SizedBox(height: 18),
          Text('No targets available yet',
              style: Theme.of(context).textTheme.headlineSmall,
              textAlign: TextAlign.center),
          const SizedBox(height: 10),
          const Text(
            'On Android, target discovery depends on supported launcher shortcuts. '
            'On iPhone and iPad, use the Shortcuts/Home Screen workflow.',
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 20),
          FilledButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Continue with platform guide'),
          ),
        ],
      ),
    ),
  );
}