
import 'package:flutter/material.dart';
import 'create_icon_flow_screen.dart';
import 'home_dashboard_screen.dart';
import 'my_icons_screen.dart';
import 'icon_packs_screen.dart';
import 'collections_screen.dart';
import 'settings_screen.dart';

class AppShell extends StatefulWidget {
  const AppShell({super.key});

  @override
  State<AppShell> createState() => _AppShellState();
}

class _AppShellState extends State<AppShell> {
  int _index = 0;
  int _refreshToken = 0;

  void goTo(int index) {
    setState(() => _index = index);
  }

  void refreshAll() {
    setState(() => _refreshToken++);
  }

  @override
  Widget build(BuildContext context) {
    final pages = <Widget>[
      HomeDashboardScreen(
        key: ValueKey('home-$_refreshToken'),
        onNavigate: goTo,
      ),
      CreateIconFlowScreen(
        key: ValueKey('create-$_refreshToken'),
        onSaved: () {
          refreshAll();
          goTo(2);
        },
      ),
      MyIconsScreen(key: ValueKey('icons-$_refreshToken')),
      IconPacksScreen(key: ValueKey('packs-$_refreshToken')),
      CollectionsScreen(key: ValueKey('collections-$_refreshToken')),
      SettingsScreen(key: ValueKey('settings-$_refreshToken')),
    ];

    return Scaffold(
      body: IndexedStack(index: _index, children: pages),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _index,
        onDestinationSelected: goTo,
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'Home'),
          NavigationDestination(icon: Icon(Icons.add_circle_outline), selectedIcon: Icon(Icons.add_circle), label: 'Create'),
          NavigationDestination(icon: Icon(Icons.grid_view_outlined), selectedIcon: Icon(Icons.grid_view), label: 'My Icons'),
          NavigationDestination(icon: Icon(Icons.auto_awesome_outlined), selectedIcon: Icon(Icons.auto_awesome), label: 'Packs'),
          NavigationDestination(icon: Icon(Icons.folder_outlined), selectedIcon: Icon(Icons.folder), label: 'Collections'),
          NavigationDestination(icon: Icon(Icons.settings_outlined), selectedIcon: Icon(Icons.settings), label: 'Settings'),
        ],
      ),
    );
  }
}
