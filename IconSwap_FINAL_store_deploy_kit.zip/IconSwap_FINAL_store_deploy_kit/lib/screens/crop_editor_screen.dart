import 'dart:io';
import 'package:flutter/material.dart';

class CropEditorScreen extends StatefulWidget {
  final File image;
  const CropEditorScreen({super.key, required this.image});

  @override
  State<CropEditorScreen> createState() => _CropEditorScreenState();
}

class _CropEditorScreenState extends State<CropEditorScreen> {
  double scale = 1;
  Offset offset = Offset.zero;
  double rotation = 0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Crop & position'),
        actions: [
          IconButton(
            tooltip: 'Reset',
            onPressed: () => setState(() {
              scale = 1;
              offset = Offset.zero;
              rotation = 0;
            }),
            icon: const Icon(Icons.refresh),
          ),
        ],
      ),
      body: Column(
        children: [
          Expanded(
            child: Center(
              child: AspectRatio(
                aspectRatio: 1,
                child: Container(
                  margin: const EdgeInsets.all(20),
                  clipBehavior: Clip.antiAlias,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(30),
                    color: Theme.of(context).colorScheme.surfaceContainerHighest,
                  ),
                  child: GestureDetector(
                    onScaleUpdate: (details) {
                      setState(() {
                        scale = (scale * details.scale).clamp(.5, 4.0);
                        offset += details.focalPointDelta;
                      });
                    },
                    child: Stack(
                      fit: StackFit.expand,
                      children: [
                        Transform(
                          alignment: Alignment.center,
                          transform: Matrix4.identity()
                            ..translate(offset.dx, offset.dy)
                            ..rotateZ(rotation)
                            ..scale(scale),
                          child: Image.file(widget.image, fit: BoxFit.cover),
                        ),
                        IgnorePointer(
                          child: CustomPaint(painter: _CropGridPainter()),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 0, 20, 12),
            child: Column(
              children: [
                Row(
                  children: [
                    const Icon(Icons.rotate_left),
                    Expanded(
                      child: Slider(
                        value: rotation,
                        min: -3.14159,
                        max: 3.14159,
                        onChanged: (v) => setState(() => rotation = v),
                      ),
                    ),
                    const Icon(Icons.rotate_right),
                  ],
                ),
                Row(
                  children: [
                    const Icon(Icons.zoom_out),
                    Expanded(
                      child: Slider(
                        value: scale,
                        min: .5,
                        max: 4,
                        onChanged: (v) => setState(() => scale = v),
                      ),
                    ),
                    const Icon(Icons.zoom_in),
                  ],
                ),
                const SizedBox(height: 6),
                FilledButton.icon(
                  onPressed: () => Navigator.pop(context, {
                    'scale': scale,
                    'offsetX': offset.dx,
                    'offsetY': offset.dy,
                    'rotation': rotation,
                  }),
                  icon: const Icon(Icons.check),
                  label: const Text('Use crop'),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _CropGridPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final p = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1
      ..color = Colors.white.withOpacity(.55);
    final thirdW = size.width / 3;
    final thirdH = size.height / 3;
    for (int i = 1; i < 3; i++) {
      canvas.drawLine(Offset(thirdW * i, 0), Offset(thirdW * i, size.height), p);
      canvas.drawLine(Offset(0, thirdH * i), Offset(size.width, thirdH * i), p);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}