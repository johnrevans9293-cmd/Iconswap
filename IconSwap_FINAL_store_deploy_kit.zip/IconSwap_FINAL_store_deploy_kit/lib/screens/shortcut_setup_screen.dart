import 'dart:typed_data';
import 'package:flutter/material.dart';
import '../services/platform_service.dart';

class ShortcutSetupScreen extends StatefulWidget {
  final String name;
  final Uint8List iconBytes;
  const ShortcutSetupScreen({super.key, required this.name, required this.iconBytes});

  @override State<ShortcutSetupScreen> createState() => _ShortcutSetupScreenState();
}

class _ShortcutSetupScreenState extends State<ShortcutSetupScreen> {
  final platform = PlatformService();
  bool? supported;
  bool busy = false;
  String? status;

  @override void initState() { super.initState(); _check(); }

  Future<void> _check() async {
    final value = await platform.canPinShortcut();
    if (mounted) setState(() => supported = value);
  }

  Future<void> _add() async {
    setState(() { busy = true; status = null; });
    final ok = await platform.requestPinShortcut(widget.name, widget.iconBytes);
    if (!mounted) return;
    setState(() {
      busy = false;
      status = ok
        ? 'Shortcut request sent. Complete the launcher confirmation if shown.'
        : 'This launcher did not accept the request. Use the manual Home Screen guide instead.';
    });
  }

  @override Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Add to Home Screen')),
      body: ListView(
        padding: const EdgeInsets.all(24),
        children: [
          Container(
            height: 210,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(32),
              color: Theme.of(context).colorScheme.surfaceContainerHighest,
            ),
            child: Center(
              child: widget.iconBytes.isEmpty
                ? const Icon(Icons.image_outlined, size: 72)
                : ClipRRect(
                    borderRadius: BorderRadius.circular(28),
                    child: Image.memory(widget.iconBytes, width: 150, height: 150, fit: BoxFit.cover),
                  ),
            ),
          ),
          const SizedBox(height: 24),
          Text(widget.name, style: Theme.of(context).textTheme.headlineSmall, textAlign: TextAlign.center),
          const SizedBox(height: 12),
          const Text(
            'IconSwap uses Android’s supported pinned-shortcut mechanism. '
            'It does not modify another installed app or replace its package icon.',
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 24),
          if (supported == false)
            const Card(child: Padding(
              padding: EdgeInsets.all(16),
              child: Text('Pinned shortcuts are not available from this launcher. You can use the manual Home Screen guide.'),
            )),
          if (status != null) ...[
            const SizedBox(height: 12),
            Text(status!, textAlign: TextAlign.center),
          ],
          const SizedBox(height: 28),
          FilledButton.icon(
            onPressed: supported == true && !busy ? _add : null,
            icon: busy
              ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2))
              : const Icon(Icons.add_to_home_screen),
            label: Text(busy ? 'Requesting…' : 'Add shortcut'),
          ),
        ],
      ),
    );
  }
}