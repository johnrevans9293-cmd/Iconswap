class IconPack {
  final String id, name, category;
  final List<String> assetPaths;
  const IconPack({required this.id,required this.name,required this.category,required this.assetPaths});
}
