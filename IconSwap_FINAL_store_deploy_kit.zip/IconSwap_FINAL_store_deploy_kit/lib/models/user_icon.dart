class UserIcon {
  final String id, name, imagePath;
  final DateTime createdAt;
  final String? targetLabel;
  const UserIcon({required this.id, required this.name, required this.imagePath,
    required this.createdAt, this.targetLabel});
  Map<String,dynamic> toJson()=>{'id':id,'name':name,'imagePath':imagePath,
    'createdAt':createdAt.toIso8601String(),'targetLabel':targetLabel};
  factory UserIcon.fromJson(Map<String,dynamic> j)=>UserIcon(
    id:j['id'],name:j['name'],imagePath:j['imagePath'],
    createdAt:DateTime.parse(j['createdAt']),targetLabel:j['targetLabel']);
}
