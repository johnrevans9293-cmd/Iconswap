
class ReleaseInfoService {
  static const appName = 'IconSwap';
  static const version = '1.0.0';
  static const build = '1';

  static const androidNote =
      'Android Home Screen behavior depends on supported launcher shortcut APIs.';
  static const iosNote =
      'iOS uses supported Shortcuts/Home Screen workflows and cannot arbitrarily replace other apps.';
}
