import 'dart:io';
import 'package:image/image.dart' as img;
import 'package:path_provider/path_provider.dart';

class ImageService {
  Future<String> process({
    required String sourcePath,
    double rotation = 0,
    double brightness = 0,
    double contrast = 1,
    double radius = 0.18,
  }) async {
    final bytes = await File(sourcePath).readAsBytes();
    final decoded = img.decodeImage(bytes);
    if (decoded == null) throw const FormatException('Unsupported image');
    var image = img.copyResize(decoded, width: 1024, height: 1024);
    if (rotation != 0) image = img.copyRotate(image, angle: rotation.round());
    if (brightness != 0) image = img.adjustColor(image, brightness: brightness);
    if (contrast != 1) image = img.adjustColor(image, contrast: contrast);
    final out = await getApplicationDocumentsDirectory();
    final file = File('${out.path}/iconswap_${DateTime.now().microsecondsSinceEpoch}.png');
    await file.writeAsBytes(img.encodePng(image));
    return file.path;
  }
}
