import 'dart:io';
import 'package:image/image.dart' as img;

class IconProcessing {
  Future<String> cropSquare(String input) async {
    final bytes=await File(input).readAsBytes();
    final image=img.decodeImage(bytes);
    if(image==null) throw const FormatException('Invalid image');
    final size=image.width<image.height?image.width:image.height;
    final x=(image.width-size)~/2, y=(image.height-size)~/2;
    final cropped=img.copyCrop(image,x:x,y:y,width:size,height:size);
    final output='$input.iconswap_crop.png';
    await File(output).writeAsBytes(img.encodePng(cropped));
    return output;
  }

  Future<String> removeSimpleBackground(String input,{int tolerance=28}) async {
    final bytes=await File(input).readAsBytes();
    final image=img.decodeImage(bytes);
    if(image==null) throw const FormatException('Invalid image');
    final corner=image.getPixel(0,0);
    final cr=corner.r, cg=corner.g, cb=corner.b;
    for(int y=0;y<image.height;y++){
      for(int x=0;x<image.width;x++){
        final p=image.getPixel(x,y);
        if((p.r-cr).abs()<tolerance && (p.g-cg).abs()<tolerance && (p.b-cb).abs()<tolerance){
          image.setPixelRgba(x,y,p.r.toInt(),p.g.toInt(),p.b.toInt(),0);
        }
      }
    }
    final output='$input.iconswap_transparent.png';
    await File(output).writeAsBytes(img.encodePng(image));
    return output;
  }
}
