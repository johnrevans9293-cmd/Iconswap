import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/user_icon.dart';
class StorageService {
  static const key='user_icons';
  Future<List<UserIcon>> load() async {
    final p=await SharedPreferences.getInstance();
    return (p.getStringList(key)??[]).map((x)=>UserIcon.fromJson(jsonDecode(x))).toList();
  }
  Future<void> save(List<UserIcon> items) async {
    final p=await SharedPreferences.getInstance();
    await p.setStringList(key,items.map((x)=>jsonEncode(x.toJson())).toList());
  }
}
