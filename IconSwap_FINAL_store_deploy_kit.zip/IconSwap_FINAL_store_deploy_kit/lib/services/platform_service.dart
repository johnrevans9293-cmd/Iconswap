import 'dart:typed_data';
import 'package:flutter/services.dart';

class PlatformService {
  static const channel = MethodChannel('iconswap/platform');

  Future<bool> canPinShortcut() async {
    try { return await channel.invokeMethod<bool>('canPinShortcut') ?? false; }
    catch (_) { return false; }
  }

  Future<bool> requestPinShortcut(String name, Uint8List iconBytes) async {
    try {
      return await channel.invokeMethod<bool>('requestPinShortcut', {
        'name': name, 'iconBytes': iconBytes,
      }) ?? false;
    } catch (_) { return false; }
  }
}