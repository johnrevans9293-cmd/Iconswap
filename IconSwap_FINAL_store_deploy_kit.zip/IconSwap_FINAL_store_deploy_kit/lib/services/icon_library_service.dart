import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';

class SavedIcon {
  final String id;
  final String name;
  final String imagePath;
  final String createdAt;
  final String collection;
  final String? targetName;

  const SavedIcon({
    required this.id,
    required this.name,
    required this.imagePath,
    required this.createdAt,
    this.collection = 'Favorites',
    this.targetName,
  });

  Map<String, dynamic> toJson() => {
    'id': id,
    'name': name,
    'imagePath': imagePath,
    'createdAt': createdAt,
    'collection': collection,
    'targetName': targetName,
  };

  factory SavedIcon.fromJson(Map<String, dynamic> json) => SavedIcon(
    id: json['id'] as String,
    name: json['name'] as String,
    imagePath: json['imagePath'] as String,
    createdAt: json['createdAt'] as String,
    collection: (json['collection'] as String?) ?? 'Favorites',
    targetName: json['targetName'] as String?,
  );
}

class IconLibraryService {
  static const _key = 'iconswap_saved_icons';

  Future<List<SavedIcon>> load() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getStringList(_key) ?? [];
    return raw
        .map((s) => SavedIcon.fromJson(jsonDecode(s) as Map<String, dynamic>))
        .toList();
  }

  Future<void> save(SavedIcon icon) async {
    final items = await load();
    items.removeWhere((x) => x.id == icon.id);
    items.insert(0, icon);
    await _write(items);
  }

  Future<void> delete(String id) async {
    final items = await load();
    items.removeWhere((x) => x.id == id);
    await _write(items);
  }

  Future<void> rename(String id, String name) async {
    final items = await load();
    final index = items.indexWhere((x) => x.id == id);
    if (index == -1) return;
    final old = items[index];
    items[index] = SavedIcon(
      id: old.id,
      name: name,
      imagePath: old.imagePath,
      createdAt: old.createdAt,
      collection: old.collection,
      targetName: old.targetName,
    );
    await _write(items);
  }

  Future<void> moveToCollection(String id, String collection) async {
    final items = await load();
    final index = items.indexWhere((x) => x.id == id);
    if (index == -1) return;
    final old = items[index];
    items[index] = SavedIcon(
      id: old.id,
      name: old.name,
      imagePath: old.imagePath,
      createdAt: old.createdAt,
      collection: collection,
      targetName: old.targetName,
    );
    await _write(items);
  }

  Future<void> _write(List<SavedIcon> items) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setStringList(
      _key,
      items.map((x) => jsonEncode(x.toJson())).toList(),
    );
  }
}