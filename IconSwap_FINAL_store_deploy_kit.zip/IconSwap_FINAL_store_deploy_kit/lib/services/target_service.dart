class TargetShortcut {
  final String id;
  final String name;
  final String? packageName;

  const TargetShortcut({
    required this.id,
    required this.name,
    this.packageName,
  });
}

/// Platform-neutral target model.
/// Platform implementations can populate this with supported launcher shortcuts.
/// It intentionally does not inspect private app data or modify installed packages.
class TargetService {
  Future<List<TargetShortcut>> discoverSupportedTargets() async {
    return const [];
  }
}