
import 'package:shared_preferences/shared_preferences.dart';

class AppSettingsService {
  static const _appearanceKey = 'appearance';
  static const _qualityKey = 'icon_quality';
  static const _shapeKey = 'default_shape';
  static const _notificationsKey = 'notifications';

  Future<SharedPreferences> get _prefs => SharedPreferences.getInstance();

  Future<String> getAppearance() async =>
      (await _prefs).getString(_appearanceKey) ?? 'system';

  Future<void> setAppearance(String value) async =>
      (await _prefs).setString(_appearanceKey, value);

  Future<String> getIconQuality() async =>
      (await _prefs).getString(_qualityKey) ?? 'High';

  Future<void> setIconQuality(String value) async =>
      (await _prefs).setString(_qualityKey, value);

  Future<String> getDefaultShape() async =>
      (await _prefs).getString(_shapeKey) ?? 'rounded';

  Future<void> setDefaultShape(String value) async =>
      (await _prefs).setString(_shapeKey, value);

  Future<bool> getNotifications() async =>
      (await _prefs).getBool(_notificationsKey) ?? true;

  Future<void> setNotifications(bool value) async =>
      (await _prefs).setBool(_notificationsKey, value);
}
