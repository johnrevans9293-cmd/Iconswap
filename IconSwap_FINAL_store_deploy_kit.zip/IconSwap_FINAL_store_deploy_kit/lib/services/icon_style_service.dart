import 'dart:ui';

class IconStyle {
  final double cornerRadius;
  final double borderWidth;
  final double shadowBlur;
  final double shadowOpacity;
  final double shadowOffset;
  final bool circularMask;

  const IconStyle({
    this.cornerRadius = 0.22,
    this.borderWidth = 0,
    this.shadowBlur = 0,
    this.shadowOpacity = 0,
    this.shadowOffset = 0,
    this.circularMask = false,
  });

  IconStyle copyWith({
    double? cornerRadius,
    double? borderWidth,
    double? shadowBlur,
    double? shadowOpacity,
    double? shadowOffset,
    bool? circularMask,
  }) => IconStyle(
    cornerRadius: cornerRadius ?? this.cornerRadius,
    borderWidth: borderWidth ?? this.borderWidth,
    shadowBlur: shadowBlur ?? this.shadowBlur,
    shadowOpacity: shadowOpacity ?? this.shadowOpacity,
    shadowOffset: shadowOffset ?? this.shadowOffset,
    circularMask: circularMask ?? this.circularMask,
  );
}

class IconStylePainter extends CustomPainter {
  final IconStyle style;
  const IconStylePainter(this.style);

  @override
  void paint(Canvas canvas, Size size) {
    final rect = Offset.zero & size;
    final radius = style.circularMask
        ? size.shortestSide / 2
        : size.shortestSide * style.cornerRadius;

    final rrect = RRect.fromRectAndRadius(rect, Radius.circular(radius));

    if (style.shadowBlur > 0 && style.shadowOpacity > 0) {
      final shadowPaint = Paint()
        ..color = const Color(0xFF000000).withOpacity(style.shadowOpacity)
        ..maskFilter = MaskFilter.blur(BlurStyle.normal, style.shadowBlur);
      canvas.drawRRect(
        rrect.shift(Offset(style.shadowOffset, style.shadowOffset)),
        shadowPaint,
      );
    }

    if (style.borderWidth > 0) {
      final borderPaint = Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = style.borderWidth
        ..color = const Color(0xFFFFFFFF).withOpacity(.9);
      canvas.drawRRect(
        rrect.deflate(style.borderWidth / 2),
        borderPaint,
      );
    }
  }

  @override
  bool shouldRepaint(covariant IconStylePainter oldDelegate) =>
      oldDelegate.style != style;
}