# IconSwap v0.4

A cross-platform custom icon editor and supported Home Screen shortcut utility.

## v0.4 additions
- Icon Packs browser with starter categories
- Square crop processing utility
- Simple local background-transparency utility based on corner-color tolerance
- Improved Home screen navigation
- Original-artwork-friendly architecture

## Important
The background tool is deliberately a simple local algorithm, not an AI
background-removal service. A production version can replace it with a stronger
on-device segmentation model.

IconSwap does not modify, patch, inject into, or repackage other applications.
Android shortcuts are launcher-managed. iOS must use public Shortcuts/Home Screen
mechanisms and cannot arbitrarily replace another app's icon.

## Setup
flutter pub get
flutter run

For Android, ensure AndroidX core is configured in the generated app module.

## v0.5 — Pro editor foundation

This build adds:
- Icon styling controls for rounded/circular masks, borders and shadows.
- Reusable platform guidance for Android and iOS.
- Collections foundation (Favorites, Work, Social, Games).
- A platform-neutral target/shortcut model for future app/shortcut selection.
- Clear documentation that IconSwap creates supported shortcuts/workflows rather than modifying another installed app.

### Important platform behavior
IconSwap never patches APKs, modifies installed bundles, uses root/private APIs, or reads another app's private data.


## v0.6 — Create Icon workflow

Added:
- Interactive crop/position screen with pinch zoom, pan and rotation.
- Create Icon flow connecting image selection, crop, style, target selection and Home Screen guidance.
- Target picker architecture for supported Android shortcuts.
- Safe fallback when platform target discovery is unavailable.
- Clear Home Screen setup step for Android/iOS platform limitations.

Note: this build intentionally does not pretend that iOS or Android can replace another installed app's package icon. It uses supported shortcut/workflow concepts only.


## v0.7 — Android shortcut integration
- Real AndroidX `ShortcutManagerCompat` pinned-shortcut bridge.
- Launcher capability detection.
- Custom bitmap shortcut support.
- Dedicated Home Screen setup UI.
- No APK patching, package modification, root/private APIs, or private app data access.


## v0.8 — My Icons library

Added:
- Persistent local icon library using SharedPreferences metadata.
- App-private image copies using path_provider.
- Search and collection filters.
- Rename, move between collections, and delete actions.
- Create Icon now saves designs into My Icons.

All icon metadata and image copies remain local to the app.


## v0.9 — Connected Dashboard & Settings
- Added a real app shell with bottom navigation for Home, Create, My Icons, Packs, Collections, and Settings.
- Home now reads recently created icons from the persistent local library and provides search.
- Collections now reflect persisted icon collection assignments.
- Added persistent Settings for theme preference, icon quality, default shape, and notifications.
- Added platform limitations/privacy/about guidance from Settings.
- Added refresh handoff after Create so saved icons appear immediately in the library/dashboard.
- Kept Android shortcut support and iOS platform-safe guidance intact.
- No arbitrary third-party app icon replacement, package modification, private APIs, root access, or other unsupported mechanisms.


## v0.10 — Release Candidate
- Added production release checklist.
- Added Google Play listing draft.
- Added Apple App Store listing draft.
- Added privacy-policy draft for publisher review.
- Added Android/iOS release build instructions.
- Added explicit store-compliance notes about launcher shortcuts and iOS limitations.
- Added release metadata service.


## v1.0.0 — Production Source Candidate
- Canonicalized the Flutter app entry point and fixed the existing basic widget test.
- Bumped release version to `1.0.0+1`.
- Added official Flutter platform bootstrap scripts for Android and iOS.
- Added production status documentation distinguishing completed source work from account/signing steps.


## v1.0.1 — Store Hardening
- Added CI quality gate.
- Added safe Android signing template and secret-focused `.gitignore`.
- Added store submission matrix.
- Added release readiness validator.
- Added final production handoff and branding asset checklist.


## v1.0.2 — Store Asset Package
- Added final Google Play metadata package.
- Added final Apple App Store metadata package.
- Added screenshot capture plan.
- Added publisher submission-values template.
- Added release command guide.
