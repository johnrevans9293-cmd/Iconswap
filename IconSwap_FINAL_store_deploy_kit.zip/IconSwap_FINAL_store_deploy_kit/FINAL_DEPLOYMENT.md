# IconSwap — Final Deployment

## What this package is

IconSwap source is prepared for production release. Version: 1.0.4+4.

## Important

This package does not contain private signing keys, Apple certificates, provisioning profiles, or Google Play credentials. Those must belong to the publisher.

## Fastest deployment route

### Option A — Codemagic

1. Create a Codemagic account.
2. Connect the IconSwap repository/ZIP contents.
3. Configure Android signing in the Codemagic environment group `iconswap_android_signing`.
4. Configure Apple signing in `iconswap_ios_signing`.
5. Run `iconswap-android-release` to obtain the `.aab`.
6. Run `iconswap-ios-release` to obtain the `.ipa`.
7. Upload the Android AAB to Google Play Console.
8. Upload the iOS IPA through App Store Connect.

The included `codemagic.yaml` contains the build definitions.

### Option B — Local machine

Install Flutter stable.

Run:

    flutter pub get
    flutter analyze
    flutter test
    bash tooling/bootstrap_platforms.sh

Android:

    flutter build appbundle --release

iOS (macOS):

    flutter build ipa --release

Then use the resulting signed artifacts for store submission.

## Store information still required from the publisher

- Legal developer/publisher name
- Support email
- Privacy-policy URL
- Google Play developer account
- Apple Developer account
- Android package/application ID confirmation
- iOS Bundle Identifier confirmation
- Store screenshots
- Final app icon assets
- Signing credentials

## Platform behavior

IconSwap must not claim that it can directly replace arbitrary third-party app package icons. Android uses supported launcher shortcut mechanisms where available. iOS uses public Shortcuts/Home Screen workflows and Apple's supported APIs. No root, private APIs, APK patching, injection, or private app data access is used.
