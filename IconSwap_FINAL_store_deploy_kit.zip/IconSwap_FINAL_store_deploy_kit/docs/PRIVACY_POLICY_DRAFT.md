# IconSwap Privacy Policy — Draft

**Last updated:** [INSERT DATE]

IconSwap is designed as a local-first icon customization utility.

### Information stored
Icons and related metadata created by the user may be stored locally on the device so the user can view and manage their library.

### Photos and media
When the user chooses an image, IconSwap uses the operating system's supported photo/camera mechanisms. Images are processed for the requested icon customization features.

### Network
IconSwap should not upload user-created images unless a future feature explicitly tells the user that an upload is occurring and obtains appropriate consent.

### Third-party apps
IconSwap does not access private data belonging to other installed applications and does not modify, patch, inject into, or repackage those applications.

### Analytics and advertising
This release does not require advertising or third-party analytics to provide its core icon-editing functionality.

### Children's privacy
IconSwap is not designed to collect personal information from children.

### Contact
Replace this section with the publisher's legal/contact details before store submission.

This document is a draft and should be reviewed and finalized by the publisher before publication.
