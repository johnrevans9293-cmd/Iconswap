# Store Submission Matrix

| Item | Android | iOS |
|---|---|---|
| Release artifact | Signed AAB | Signed IPA/archive |
| Signing | Google Play App Signing / upload key | Apple Developer signing |
| Store console | Google Play Console | App Store Connect |
| Testing | Internal/closed testing | TestFlight |
| Screenshots | Required | Required |
| Privacy information | Data Safety + privacy policy | App Privacy + privacy policy |
| Icon behavior | Supported pinned shortcuts where launcher allows | Supported Shortcuts/Home Screen workflow |
| Arbitrary third-party icon replacement | Not supported | Not supported |
| Private APIs/package modification | Not used | Not used |

Before submission:
- Replace publisher placeholders in store/legal documents.
- Capture screenshots from the final signed build.
- Verify application ID/bundle identifier.
- Verify publisher name, support email and privacy URL.
- Test the exact release build on physical devices.
