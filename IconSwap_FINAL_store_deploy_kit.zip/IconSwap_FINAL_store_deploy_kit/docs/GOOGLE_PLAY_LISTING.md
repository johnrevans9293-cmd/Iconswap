# Google Play Store Listing Draft

## App name
IconSwap

## Short description
Create, style, organize, and save custom Home Screen icons.

## Full description
Make your Home Screen your own with IconSwap.

Create custom icons from your photos or artwork, crop and style them, organize your collection, and preview your designs before adding supported shortcuts to your Home Screen.

### Create
- Import an image from your device
- Crop, zoom, rotate and adjust your design
- Tune brightness and contrast
- Apply shapes, borders and shadows
- Save your finished icon locally

### Organize
- Search your saved icons
- Rename and delete icons
- Move icons into collections
- Browse recently created designs

### Icon packs
Explore built-in style categories including Minimal, Glass, Neon, Dark, Pastel, Gradient, Gaming, Productivity and Nature.

### Android shortcuts
On supported Android launchers, IconSwap can request a pinned Home Screen shortcut using supported Android APIs. Availability and behavior depend on the launcher and Android version.

### Important platform note
IconSwap does not modify or replace another app's package, private data, or installed APK. Android shortcut behavior varies by launcher.

Your icons are designed to stay on your device unless a future feature explicitly states otherwise.

**Suggested category:** Personalization
