# IconSwap — Final Handoff

The source project is prepared for the production build stage.

1. Install Flutter stable and run `flutter doctor`.
2. Run `flutter pub get`.
3. Run `flutter analyze`.
4. Run `flutter test`.
5. Run `python tooling/check_release_readiness.py`.
6. Configure Android signing privately using `android/key.properties`.
7. Build the signed Android App Bundle.
8. Configure Apple signing in Xcode on macOS.
9. Archive and upload to TestFlight.
10. Perform final physical-device QA.
11. Complete store metadata, privacy declarations and screenshots.
12. Submit for review.

Never upload keystores, passwords, Apple private keys, or API keys.

Use accurate product claims: IconSwap creates/manages custom icon artwork and supported Home Screen shortcuts/workflows. It does not modify arbitrary third-party app packages or use private APIs.
