# IconSwap Production Status

## Completed in this source package
- Connected application navigation
- Local icon library
- Create/edit/style/save flow
- Collections
- Settings
- Android supported pinned-shortcut bridge
- iOS supported workflow guidance
- Release metadata
- Store listing drafts
- Privacy-policy draft
- Release checklist
- Automated Flutter platform bootstrap scripts
- Version `1.0.0+1`

## Required on the publisher's machine/account
These cannot be completed from source code alone:
- Android release signing keystore
- Google Play Console developer account
- Google Play listing ownership/verification
- Apple Developer Program membership
- Apple signing certificates/profiles
- App Store Connect application record
- Final TestFlight/App Review submission
- Store screenshots captured from final signed builds
- Legal publisher identity/contact details

## Important product limitation
IconSwap does not replace arbitrary third-party app icons by modifying their packages. Android uses supported launcher shortcut APIs. iOS uses supported Shortcuts/Home Screen workflows.
