# IconSwap Production Release Checklist

## Product QA
- [ ] Run `flutter analyze`
- [ ] Run `flutter test`
- [ ] Test Create Icon on a physical Android device
- [ ] Test Android pinned shortcut on supported launchers
- [ ] Test unsupported-launcher messaging
- [ ] Test iOS Shortcuts/Home Screen guidance on a physical iPhone
- [ ] Test image import, crop, rotate, zoom, brightness, contrast and styling
- [ ] Test save/load/rename/move/delete
- [ ] Test Collections and Recently Created
- [ ] Test light/dark/system appearance
- [ ] Test large text and screen readers
- [ ] Test offline behavior

## Android release
- [ ] Configure a unique applicationId
- [ ] Create/upload a release keystore
- [ ] Configure `key.properties` locally (never commit it)
- [ ] Verify Android App Bundle signing
- [ ] Run `flutter build appbundle --release`
- [ ] Upload the resulting `.aab` to Play Console
- [ ] Complete Data safety, content rating and app access declarations
- [ ] Add store screenshots and listing
- [ ] Release to internal testing, then production

## iOS release
- [ ] Set unique Bundle Identifier
- [ ] Configure Apple Developer Team/signing
- [ ] Configure App Store Connect record
- [ ] Add required privacy information
- [ ] Add screenshots and app description
- [ ] Build/archive on macOS with Xcode
- [ ] Upload to TestFlight
- [ ] Test on physical iPhone/iPad
- [ ] Submit for App Review

## Store compliance
IconSwap must not claim to replace arbitrary third-party application package icons. Android functionality is based on supported launcher shortcuts. iOS functionality uses supported Shortcuts/Home Screen workflows. No root, private APIs, package patching, injection, or access to other apps' private data.
