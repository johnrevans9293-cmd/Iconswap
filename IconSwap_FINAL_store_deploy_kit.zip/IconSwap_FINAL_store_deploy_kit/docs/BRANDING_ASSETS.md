# Branding Assets Still Needed

Prepare from approved IconSwap artwork:
- App icon: 1024×1024 master
- Android adaptive icon foreground/background
- iOS App Store icon
- Play Store feature graphic
- Android phone screenshots
- iPhone screenshots
- Optional tablet screenshots

Avoid unlicensed third-party logos, copyrighted characters, or misleading UI.
