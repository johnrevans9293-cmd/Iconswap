package com.example.iconswap

import android.content.Intent
import android.graphics.BitmapFactory
import androidx.core.app.ShortcutManagerCompat
import androidx.core.content.pm.ShortcutInfoCompat
import androidx.core.graphics.drawable.IconCompat
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

class MainActivity : FlutterActivity() {
    private val channelName = "iconswap/platform"

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, channelName)
            .setMethodCallHandler { call, result ->
                when (call.method) {
                    "canPinShortcut" -> result.success(
                        ShortcutManagerCompat.isRequestPinShortcutSupported(this)
                    )
                    "requestPinShortcut" -> {
                        val name = call.argument<String>("name") ?: "IconSwap"
                        val bytes = call.argument<ByteArray>("iconBytes")
                        if (bytes == null || !ShortcutManagerCompat.isRequestPinShortcutSupported(this)) {
                            result.success(false)
                            return@setMethodCallHandler
                        }
                        val bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                        if (bitmap == null) { result.success(false); return@setMethodCallHandler }

                        val intent = Intent(this, MainActivity::class.java).apply {
                            action = Intent.ACTION_VIEW
                            putExtra("iconswap_shortcut_name", name)
                        }
                        val shortcut = ShortcutInfoCompat.Builder(this, "iconswap_${System.currentTimeMillis()}")
                            .setShortLabel(name.take(25))
                            .setLongLabel(name)
                            .setIcon(IconCompat.createWithBitmap(bitmap))
                            .setIntent(intent)
                            .build()

                        result.success(
                            ShortcutManagerCompat.requestPinShortcut(this, shortcut, null)
                        )
                    }
                    else -> result.notImplemented()
                }
            }
    }
}